package com.example.examplemod;

import com.mojang.logging.LogUtils;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.slf4j.Logger;
import net.minecraft.network.chat.Component;

// The value here should match an entry in the META-INF/mods.toml file
@Mod(ENFoodsCraft.MODID)
public class ENFoodsCraft
{
    // Define mod id in a common place for everything to reference
    public static final String MODID = "enfc";
    // Directly reference a slf4j logger
    private static final Logger LOGGER = LogUtils.getLogger();
    // Create a Deferred Register to hold Blocks which will all be registered under the "examplemod" namespace
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    // Create a Deferred Register to hold Items which will all be registered under the "examplemod" namespace
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    // Create a Deferred Register to hold CreativeModeTabs which will all be registered under the "examplemod" namespace
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    // Creates a new Block with the id "examplemod:example_block", combining the namespace and path
    public static final RegistryObject<Block> EXAMPLE_BLOCK = BLOCKS.register("example_block", () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.STONE)));
    // Creates a new BlockItem with the id "examplemod:example_block", combining the namespace and path
    public static final RegistryObject<Item> EXAMPLE_BLOCK_ITEM = ITEMS.register("example_block", () -> new BlockItem(EXAMPLE_BLOCK.get(), new Item.Properties()));

    public static final RegistryObject<Item> OAK_CAKE_ROLLS = ITEMS.register("oak_cake_rolls",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(8)
                    .effect(new MobEffectInstance(MobEffects.REGENERATION, 240, 2), 1.0f)
                    .effect(new MobEffectInstance(MobEffects.ABSORPTION, 600, 2), 1.0f)
                    .effect(new MobEffectInstance(MobEffects.SATURATION, 600, 0), 1.0f)
                    .effect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 1), 1.0f)
                    .effect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 1200, 0), 1.0f)
                    .effect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 400, 1), 1.0f)
                    .saturationModifier(3f).build())));

    public static final RegistryObject<Item> FROSTING_COOKIE = ITEMS.register("frosting_cookie",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(2)
                    .saturationModifier(0.8f).build())));

    public static final RegistryObject<Item> APPLE_PIE = ITEMS.register("apple_pie",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(6)
                    .saturationModifier(1.3f).build())));

    public static final RegistryObject<Item> GOLDEN_APPLE_PIE = ITEMS.register("golden_apple_pie",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(8)
                    .saturationModifier(1.3f)
                    .effect(new MobEffectInstance(MobEffects.REGENERATION, 140, 1), 1.0f)
                    .effect(new MobEffectInstance(MobEffects.ABSORPTION, 2600, 0), 1.0f)
                    .build())));

    public static final RegistryObject<Item> CHOCOLATE_COOKIE = ITEMS.register("chocolate_cookie",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(2)
                    .saturationModifier(0.6f).build())));

    public static final RegistryObject<Item> SWEET_BERRIES_PIE = ITEMS.register("sweet_berries_pie",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(6)
                    .saturationModifier(1.3f).build())));

    public static final RegistryObject<Item> MILK_COOKIE = ITEMS.register("milk_cookie",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(2)
                    .saturationModifier(0.6f).build())));

    public static final RegistryObject<Item> DARK_CHOCOLATE = ITEMS.register("dark_chocolate",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(2)
                    .saturationModifier(0.8f).build())));

    public static final RegistryObject<Item> OATMEAL_COOKIE = ITEMS.register("oatmeal_cookie",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(2)
                    .saturationModifier(0.6f).build())));

    public static final RegistryObject<Item> GINGERBREAD_MAN = ITEMS.register("gingerbread_man",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(3)
                    .saturationModifier(1f).build())));

    public static final RegistryObject<Item> ICE_CREAM = ITEMS.register("ice_cream",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(4)
                    .saturationModifier(1.3f).build())));

    public static final RegistryObject<Item> CHOCOLATE_PUDDING = ITEMS.register("chocolate_pudding",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(6)
                    .saturationModifier(1f).build())));

    public static final RegistryObject<Item> MILK_PUDDING = ITEMS.register("milk_pudding",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(6)
                    .saturationModifier(1f)
                    .build())));

    public static final RegistryObject<Item> GOLDEN_APPLE_PUDDING = ITEMS.register("golden_apple_pudding",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(8)
                    .effect(new MobEffectInstance(MobEffects.REGENERATION, 140, 1), 1.0f)
                    .effect(new MobEffectInstance(MobEffects.ABSORPTION, 2600, 0), 1.0f)
                    .saturationModifier(1.5f).build())));

    public static final RegistryObject<Item> PUMPKIN_PUDDING = ITEMS.register("pumpkin_pudding",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(6)
                    .saturationModifier(1f).build())));

    public static final RegistryObject<Item> WATERMELON_PUDDING = ITEMS.register("watermelon_pudding",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(4)
                    .saturationModifier(1f).build())));

    public static final RegistryObject<Item> CACTUS_PUDDING = ITEMS.register("cactus_pudding",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(4)
                    .saturationModifier(1f).build())));

    public static final RegistryObject<Item> HONEY_PUDDING = ITEMS.register("honey_pudding",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(6)
                    .saturationModifier(1f).build())));

    public static final RegistryObject<Item> CHOCOLATE_CAKE = ITEMS.register("chocolate_cake",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(12)
                    .saturationModifier(1.5f).build())));

    public static final RegistryObject<Item> CREAM_CAKE = ITEMS.register("cream_cake",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(12)
                    .saturationModifier(1.5f).build())));

    public static final RegistryObject<Item> HONEY_CAKE = ITEMS.register("honey_cake",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(12)
                    .saturationModifier(1.5f).build())));

    public static final RegistryObject<Item> APPLE_CAKE = ITEMS.register("apple_cake",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(12)
                    .saturationModifier(1.5f).build())));

    public static final RegistryObject<Item> GOLDEN_APPLE_CAKE = ITEMS.register("golden_apple_cake",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(14)
                    .effect(new MobEffectInstance(MobEffects.REGENERATION, 140, 1), 1.0f)
                    .effect(new MobEffectInstance(MobEffects.ABSORPTION, 2600, 0), 1.0f)
                    .saturationModifier(2f).build())));

    public static final RegistryObject<Item> CHOCOLATE_DONUT = ITEMS.register("chocolate_donut",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(6)
                    .saturationModifier(1.2f).build())));

    public static final RegistryObject<Item> CREAM_DONUT = ITEMS.register("cream_donut",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(6)
                    .saturationModifier(1.2f).build())));

    public static final RegistryObject<Item> HONEY_DONUT = ITEMS.register("honey_donut",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(6)
                    .saturationModifier(1.2f).build())));

    public static final RegistryObject<Item> PUMPKIN_DONUT = ITEMS.register("pumpkin_donut",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(6)
                    .saturationModifier(1.2f).build())));

    public static final RegistryObject<Item> APPLE_DONUT = ITEMS.register("apple_donut",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(6)
                    .saturationModifier(1.2f).build())));

    public static final RegistryObject<Item> CREAM = ITEMS.register("cream",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .alwaysEdible()
                    .nutrition(1)
                    .saturationModifier(0.2f).build())));

    public static final RegistryObject<CreativeModeTab> FOODS_TAB = CREATIVE_MODE_TABS.register("foods_tab", () -> CreativeModeTab.builder()
            .withTabsBefore(CreativeModeTabs.COMBAT)
            .title(Component.translatable("itemGroup.enfc.foods_tab"))
            .icon(() -> APPLE_PIE.get().getDefaultInstance())
            .displayItems((parameters, output) -> {
                output.accept(APPLE_PIE.get());
                output.accept(GOLDEN_APPLE_PIE.get());
                output.accept(SWEET_BERRIES_PIE.get());
                output.accept(CHOCOLATE_COOKIE.get());
                output.accept(FROSTING_COOKIE.get());
                output.accept(MILK_COOKIE.get());
                output.accept(DARK_CHOCOLATE.get());
                output.accept(OATMEAL_COOKIE.get());
                output.accept(GINGERBREAD_MAN.get());
                output.accept(CREAM.get());
                output.accept(ICE_CREAM.get());
                output.accept(CHOCOLATE_PUDDING.get());
                output.accept(MILK_PUDDING.get());
                output.accept(GOLDEN_APPLE_PUDDING.get());
                output.accept(PUMPKIN_PUDDING.get());
                output.accept(WATERMELON_PUDDING.get());
                output.accept(CACTUS_PUDDING.get());
                output.accept(HONEY_PUDDING.get());
                output.accept(CHOCOLATE_CAKE.get());
                output.accept(CREAM_CAKE.get());
                output.accept(HONEY_CAKE.get());
                output.accept(APPLE_CAKE.get());
                output.accept(GOLDEN_APPLE_CAKE.get());
                output.accept(APPLE_DONUT.get());
                output.accept(CHOCOLATE_DONUT.get());
                output.accept(CREAM_DONUT.get());
                output.accept(HONEY_DONUT.get());
                output.accept(PUMPKIN_DONUT.get());
                output.accept(OAK_CAKE_ROLLS.get());
            }).build());
//    public static final RegistryObject<Item> TEST_ITEM = ITEMS.register("test_item", () -> new Item(new Item.Properties()));

//    public static final RegistryObject<CreativeModeTab> MATERIAL_TAB = CREATIVE_MODE_TABS.register("material_tab", () -> CreativeModeTab.builder()
//            .withTabsBefore(CreativeModeTabs.COMBAT)
//            .title(Component.translatable("itemGroup.enfc.material_tab"))
//            .icon(() -> TEST_ITEM.get().getDefaultInstance())
//            .displayItems((parameters, output) -> {
//                output.accept(TEST_ITEM.get());// Add the example item to the tab. For your own tabs, this method is preferred over the event
//            }).build());

    public ENFoodsCraft(FMLJavaModLoadingContext context)
    {
        IEventBus modEventBus = context.getModEventBus();

        // Register the commonSetup method for modloading
        modEventBus.addListener(this::commonSetup);

        // Register the Deferred Register to the mod event bus so blocks get registered
        BLOCKS.register(modEventBus);
        // Register the Deferred Register to the mod event bus so items get registered
        ITEMS.register(modEventBus);
        // Register the Deferred Register to the mod event bus so tabs get registered
        CREATIVE_MODE_TABS.register(modEventBus);

        // Register ourselves for server and other game events we are interested in
        MinecraftForge.EVENT_BUS.register(this);

        // Register our mod's ForgeConfigSpec so that Forge can create and load the config file for us
        context.registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }

    private void commonSetup(final FMLCommonSetupEvent event)
    {
        LOGGER.info("HELLO FROM COMMON SETUP");

        if (Config.logDirtBlock)
            LOGGER.info("DIRT BLOCK >> {}", ForgeRegistries.BLOCKS.getKey(Blocks.DIRT));

        LOGGER.info(Config.magicNumberIntroduction + Config.magicNumber);

        Config.items.forEach((item) -> LOGGER.info("ITEM >> {}", item.toString()));
    }

    @SubscribeEvent
    public void onItemTooltip(ItemTooltipEvent event) {
        if (event.getItemStack().is(OAK_CAKE_ROLLS.get())) {
            event.getToolTip().add(Component.translatable("tooltip.enfc.oak_cake_rolls").withStyle(ChatFormatting.GREEN));
        }
    }
}
